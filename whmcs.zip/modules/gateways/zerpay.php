<?php
function zerpay_config()
{
    $configarray = array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'ZerPay'
        ),
        'zerpay_url' => array(
            'FriendlyName' => 'URL мерчанта (по умолчанию, //lk.zerpay.ru/pay/)',
            'Type' => 'text',
            'Size' => '100',
            'Default' => '//lk.zerpay.ru/pay/'
        ),
        'zerpay_shop' => array(
          'FriendlyName' => 'Идентификатор магазина',
          'Type' => 'text',
          'Size' => '50'
        ),
        'public_key' => array(
          'FriendlyName' => 'Публичный ключ',
          'Type' => 'text',
          'Size' => '100'
        ),
        'secret_key' => array(
          'FriendlyName' => 'Cекретный ключ',
          'Type' => 'text',
          'Size' => '100'
        ),
        'zerpay_logfile' => array(
          'FriendlyName' => 'Путь до файла для журнализации оплат (например, /zerpay_orders.log)',
          'Type' => 'text',
          'Size' => '100'
        ),
        'zerpay_ipfilter' => array(
          'FriendlyName' => 'IP - фильтр обработчика',
          'Type' => 'text',
          'Size' => '100',
          'Default' => '185.217.199.13'
        ),
        'zerpay_email_error' => array(
          'FriendlyName' => 'Email для ошибок оплаты',
          'Type' => 'text',
          'Size' => '100'
        )
    );

    return $configarray;
}

function zerpay_link($params)
{
    global $_LANG;

    $url            = $params['zerpay_url'];
    $shop_id        = $params['zerpay_shop'];
    $order_id       = $params['invoiceid'];
    $amount         = number_format($params['amount'], 2, '.', '') * 1;
    $public_key   	= $params['public_key'];

    $signature =    md5( implode( ":", array($shop_id, $amount, $public_key, $order_id)));

    $code = '
        <form id = "form_payment_freekassa" method="GET" action="' . $url . '">
            <input type="hidden" name="shop_id" value="' . $shop_id . '">
            <input type="hidden" name="amount" value="' . $amount . '">
            <input type="hidden" name="pay_id" value="' . $order_id . '">
            <input type="hidden" name="sign" value="' . $signature . '">
            <input type="submit" value="' . $_LANG['invoicespaynow'] . '" />
        </form>';

    return $code;
}