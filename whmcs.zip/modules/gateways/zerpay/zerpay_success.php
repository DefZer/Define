<?php

if (isset($_REQUEST['invoice'])) {
    header('Location: /viewinvoice.php?id=' . $_REQUEST['invoice'] . '&paymentsuccess=true');
} else {
    header('Location: /clientarea.php');
}