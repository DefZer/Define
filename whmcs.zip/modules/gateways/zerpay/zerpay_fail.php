<?php

if (isset($_REQUEST['invoice'])) {
    header('Location: /viewinvoice.php?id=' . $_REQUEST['invoice'] . '&paymentfailed=true');
} else {
    header('Location: /clientarea.php');
}