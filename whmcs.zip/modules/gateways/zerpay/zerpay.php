<?php

if (file_exists('../../../init.php')) {
    include_once('../../../init.php');
} else {
    include_once('../../../dbconnect.php');
    include_once('../../../includes/functions.php');
}

include('../../../includes/gatewayfunctions.php');
include('../../../includes/invoicefunctions.php');



$gatewaymodule = 'zerpay';
$GATEWAY = getGatewayVariables($gatewaymodule);



if ( isset($_REQUEST['invoice']) && isset($_REQUEST['http_auth_signature'])) {
	
	$signature = md5($GATEWAY['zerpay_shop'].":".$_REQUEST['sum'].":".$GATEWAY['secret_key'].":".$_REQUEST['invoice']);
    $log_text = "--------------------------------------------------------\n";
    foreach ($_REQUEST as $name => $value) {
        $log_text .= "{$name}: {$value}\n";
    }
    if ( ! empty($GATEWAY['zerpay_logfile'])){

        file_put_contents($_SERVER['DOCUMENT_ROOT'] . $GATEWAY['zerpay_logfile'], $log_text, FILE_APPEND);
    }

    if ((string)$_REQUEST["http_auth_signature"] !== (string)$signature){

        if (!empty($GATEWAY['zerpay_email_error'])){

            $to = $GATEWAY['zerpay_email_error'];
            $subject = "Ошибка оплаты";
            $message = "Не удалось провести платёж через систему ZerPay по следующим причинам:\n\n";
            $message .= " - Не совпадают цифровые подписи\n";
            $message .= "\n" . $log_text;
            $headers = "From: no-reply@" . $_SERVER['HTTP_HOST'] . "\r\nContent-type: text/plain; charset=utf-8 \r\n";
            mail($to, $subject, $message, $headers);
        }

        exit ($_REQUEST['invoice'] . ' | error signature');
    }

    // проверка принадлежности ip списку доверенных ip

    $valid_ip = false;
    $sIP = str_replace(' ', '', $GATEWAY['zerpay_ipfilter']);
    $array_IP = explode(',', $sIP);
    if (isset($_SERVER["HTTP_X_REAL_IP"])) {
        $cur_ip = $_SERVER["HTTP_X_REAL_IP"];
    } else {
        $cur_ip = $_SERVER["REMOTE_ADDR"];
    }
    if (in_array($cur_ip, $array_IP)) {
        $valid_ip = true;
    }


    if ((string)$_REQUEST['http_auth_signature'] === (string)$signature && $valid_ip){

        addInvoicePayment($_REQUEST['invoice'], $_REQUEST['MERCHANT_ID'], $payed, '', $gatewaymodule);
        logTransaction($GATEWAY['name'], $_REQUEST, 'Successful');
        exit ('YES');
    } else {

        if ( ! empty($GATEWAY['zerpay_email_error'])){

            $to = $GATEWAY['zerpay_email_error'];
            $subject = "Ошибка оплаты";
            $message = "Не удалось провести платёж через систему Freekassa по следующим причинам:\n\n";

            if ( ! $valid_ip){
                $message .= " - IP-адрес сервера не является доверенным\n";
                $message .= '   доверенные IP: ' . $sIP . "\n";
                $message .= '   IP текущего сервера: ' . $cur_ip . "\n";
            }

            $message .= "\n" . $log_text;
            $headers = 'From: no-reply@' . $_SERVER['HTTP_HOST'] . "\r\nContent-type: text/plain; charset=utf-8 \r\n";
            mail($to, $subject, $message, $headers);
        }

        logTransaction($GATEWAY['name'], $event, 'Unsuccessful');

        exit ($_REQUEST['invoice'] . ' | error | ' . !$valid_ip ? 'ip' : 'signature');
    }
} else {
    exit ($_REQUEST['invoice'] . ' | error | no parameters');
}