﻿<?php
/*
Copyright (c) 2023 ZerPay.ru
Developed by apnem19 || vk.com/apnem19 || t.me/apnem19
*/
class zerpayController extends Controller {
	public function index() {
		$this->load->model('users');
		$this->load->model('invoices');
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$errorPOST = $this->validatePOST();
			if(!$errorPOST) {
				$ammount = $this->request->post['sum'];
				$invid = $this->request->post['invoice'];
				
				$invoice = $this->invoicesModel->getInvoiceById($invid);
				$userid = $invoice['user_id'];
				
				$this->usersModel->upUserBalance($userid, $ammount);
				
				$this->invoicesModel->updateInvoice($invid, array('invoice_status' => 1));
				return "OK$invid\n";
			} else {
				return "$errorPOST";
			}
		} else {
			return "Invalid request!";
		}
	}
	
	private function validatePOST() {
		$result = null;
		
		$ammount = $this->request->post['sum'];
		$invid = $this->request->post['invoice'];
		$signature = $this->request->post['http_auth_signature'];
		
		$password = $this->config->zerpay_secretkey;
		$login = $this->config->zerpay_id;
	
		if(!$this->invoicesModel->getTotalInvoices(array('invoice_id' => (int)$invid))) {
			$result = "Invalid invoice!";
		}
        elseif(strtoupper($signature) != strtoupper(hash('sha256', "$login:$ammount:$password:$invid"))) {
			$result = "Invalid signature!";
		}
		return $result;
	}
}
?>
