#!/usr/bin/php
<?php
set_include_path(get_include_path() . PATH_SEPARATOR . "/usr/local/mgr5/include/php");
define('__MODULE__', "pmzp");
require_once 'billmgr_util.php';

$longopts  = array(
    "command:",
    "payment:",
    "amount:",
);
$options = getopt("", $longopts);

try {
    $command = $options['command'];
    //Debug("command ". $options['command']);
    if ($command == "config") {
        $config_xml = simplexml_load_string($default_xml_string);
        $feature_node = $config_xml->addChild("feature");
        $feature_node->addChild("payment_receipt", "on");
        // $feature_node->addChild("refund", "on"); // сигнализирует о поддержке отмены платежей, возврата средств. Без этой возможности обработка команд rftune, rfvalidate, rfset не требуется
        // $feature_node->addChild("transfer", "on"); // сигнализирует о поддержке перевода средств со счета в платежной системе на счет клиента. Без этой возможности обработка команд tftune, tfvalidate, tfset не требуется
        // $feature_node->addChild("recurring", "on"); // сигнализирует о поддержке рекуррентных платежей. Без этой возможности параметры recurring_script и recurring_type можно не указывать
        $feature_node->addChild("redirect", "on"); // сигнализирует о том что для совершения оплаты с помощью данного модуля будет произведен редирект в платежную систему
        // $feature_node->addChild("noselect", "on"); // метод оплаты не будет отображаться в списке при выборе клиентом. Используется в случае, если для оплаты не требуется предварительное создание платежа в BILLmanager. Например при оплате через терминал.
        $feature_node->addChild("notneedprofile", "on"); // указывается если для совершения платежа указание плательщика не обязательно. Однако, если метод оплату будет подключен к компании система запросит у клиента создание или выбор плательщика.

        $feature_node->addChild("pmtune", "on"); // указывает, если для корректного отображения формы настройки метода оплаты необходимо выполнение дополнительных действий
        $feature_node->addChild("pmvalidate", "on"); // если указано при сохранении параметров метода оплаты будет вызван модуль для проверки введенных значений

        // $feature_node->addChild("crtune", "on"); // указывается, если для корректного отображения формы оплаты требуется выполнении дополнительных действий.
        // $feature_node->addChild("crvalidate", "on"); // если указан при сохранении введенных клиентом значений будет вызван модуль для проверки введенных значений
        // $feature_node->addChild("crset", "on"); // указывается, если перед переадресацией на оплату требуется выполнение каких-либо действий модулем, либо если оплата совершается без перехода в платежную систему
        // $feature_node->addChild("crdelete", "on"); // указывается, если для корректного удаления платежа необходимо выполнение действий на стороне платежной системы

        // $feature_node->addChild("rcset", "on"); // аналогично crset, но при настройке рекуррентных платежей со стороны клиента. Используется для настройки рекуррентных платежей со стороны платежной системы
        // $feature_node->addChild("rcpay", "on"); // вызывается при создании в BILLmanager рекуррентного платежа. Используется для вызова оплаты со стороны платежной системы

        // $feature_node->addChild("rftune", "on"); // аналогично crtune, но при возврате средств
        // $feature_node->addChild("rfvalidate", "on"); // аналогично crvalidate, но при возврате средств
        // $feature_node->addChild("rfset", "on"); // в общем случае обязательная возможность для возврата средств. При вызове данной команды выполняются все необходимые действия для выполнения возврата

        // $feature_node->addChild("tftune", "on"); // аналогично crtune, но при переводе средств
        // $feature_node->addChild("tfvalidate", "on"); // аналогично crvalidate, но при переводе средств
        // $feature_node->addChild("tfset", "on"); // в общем случае обязательная возможность для перевода средств. При вызове данной команды выполняются все необходимые действия для выполнения перевода

        $param_node = $config_xml->addChild("param");
        $param_node->addChild("payment_script", "/mancgi/zppayment.php");
        echo $config_xml->asXML();
    } elseif ($command == "pmtune") {
        $paymethod_form = simplexml_load_string(file_get_contents('php://stdin'));
        echo $paymethod_form->asXML();
    } elseif ($command == "pmvalidate") {
        $paymethod_form = simplexml_load_string(file_get_contents('php://stdin'));
        echo $paymethod_form->asXML();
    } else {
        throw new Error("unknown command");
    }
} catch (Exception $e) {
    echo $e;
}

?>