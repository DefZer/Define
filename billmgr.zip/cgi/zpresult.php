#!/usr/bin/php
<?php
set_include_path(get_include_path() . PATH_SEPARATOR . "/usr/local/mgr5/include/php");
define('__MODULE__', "pmzp");
require_once 'billmgr_util.php';

echo "Content-Type: text/html; charset=utf-8\n\n";

Debug('Вошли в файл zpresult.php');
$params = CgiInput(true);

if (!function_exists('hash_equals')) {
    function hash_equals($str1, $str2) {
        if (strlen($str1) != strlen($str2)) return false;
        $res = $str1 ^ $str2;
        $ret = 0;
        for ($i = strlen($res) - 1; $i >= 0; $i--) {
            $ret |= ord($res[$i]);
        }
        return !$ret;
    }
}

if ($params) {
    $order_id = $params["invoice"];
    if (!$order_id) {
        Error('Empty order ID!');
        exit;
    }
    $info = LocalQuery("payment.info", array("elid" => $order_id));
    if ($info->payment->id) { //заказ сушествует в BM
        $sum = $params["sum"];
        $sum = $sum * 1;

        $paymethod_params = (array) $info->payment->paymethod[1];

        $merchant_id = $paymethod_params["merchant_id"];
        $secret_key = html_entity_decode($paymethod_params["secret_key"]);

        $sign = md5($merchant_id.':'.$sum.':'.$secret_key.':'.$order_id);
        if (hash_equals($sign, $params['http_auth_signature'])) {
            LocalQuery("payment.setpaid", array("elid" => $order_id, 'externalid' => $order_id, 'info' => print_r($params, true)));
            Debug("payment.setpaid OK {$order_id}");
			echo("OK".$order_id);
			exit(0);
        } else {
            Error('Hash signature does not match');
            Error("merchant_id {$order_id} sum {$sum} secret_key {$secret_key} order_id {$order_id} sign {$sign}");
        }
    } else {
        Error("Order not found in BM!");
    }
} else {
    Error("Empty params!");
}
echo("ERROR");
?>