#!/usr/bin/php
<?php
set_include_path(get_include_path() . PATH_SEPARATOR . "/usr/local/mgr5/include/php");
define('__MODULE__', "pmzp");
require_once 'billmgr_util.php';

echo "Content-Type: text/html; charset=utf-8\n\n";
$client_ip = ClientIp();
$param = CgiInput();
//Debug("INPUT PARAMS: ".print_r($param, true));

if (empty($param['elid'])) throw new Exception("EMPTY ELID!");

$info = LocalQuery("payment.info", array("elid" => $param["elid"]));

$elid = (string)$info->payment->id;

$sum = $info->payment->paymethodamount;
$sum = $sum * 1;

$paymethod_params = (array)$info->payment->paymethod[1];

$merchant_id = $paymethod_params["merchant_id"];
$public_key = html_entity_decode($paymethod_params["public_key"]);

$project_params = (array)$info->payment->project;

$order_name = $project_params["name"] . " #" . $elid;

$lang = _get_locale_lang("billmgrlang5");

if (is_null($lang)) {
    $lang = _get_locale_lang("billmgrlang6");
}

$lang = (is_null($lang)) ? 'ru' : $lang;

$params = array(
    'shop_id' => $merchant_id,
    'amount' => $sum,
    'pay_id' => $elid,
    'sign' => md5($merchant_id . ':' . $sum . ':' . $public_key . ':' . $elid)
);

if (!empty($paymethod_params['paymentreceipt_type']) && $info->payment->items) {
    $params['gds'] = array();
    $payment_receipt_desc = $paymethod_params['payment_receipt_description'];
    foreach ($info->payment->items->item as $item) {
        $name = (string)$item->locale_name;
        if (stripos($name, 'Авансовый') !== false) {
            $name = $payment_receipt_desc;
        }
        $params['gds'][] = array(
            'name' => $name,
            'price' => (string)$item->amount,
            'quantity' => 1,
        );
    }
}

$inputs = '';
foreach ($params as $key => $value) {
    if ($key == 'gds') {
        foreach ($value as $index => $val) {
            $inputs .= '<input type="hidden" name="gds[' . $index . '][name]" value="' . htmlspecialchars($val['name']) . '">';
            $inputs .= '<input type="hidden" name="gds[' . $index . '][price]" value="' . $val['price'] . '">';
            $inputs .= '<input type="hidden" name="gds[' . $index . '][quantity]" value="' . $val['quantity'] . '">';
        }
    } else {
        $inputs .= '<input type="hidden" name="' . $key . '" value="' . htmlspecialchars($value) . '">';
    }
}

function _get_locale_lang($cookie_name)
{
    $lang = null;

    if (isset($_COOKIE[$cookie_name])) {
        Debug("Language by standart cookie");
        $cookie = $_COOKIE[$cookie_name];
        list($area, $lang) = explode(":", $cookie);
    } elseif (isset($_SERVER["HTTP_COOKIE"])) {
        Debug("Language by server cookie");
        $cookies = explode("; ", $_SERVER["HTTP_COOKIE"]);
        foreach ($cookies as $cookie) {
            $param_line = explode("=", $cookie);
            if (count($param_line) > 1 && $param_line[0] == $cookie_name) {
                list($area, $lang) = explode(":", $param_line[1]);
            }
        }
    }

    return $lang;
}

echo '
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
</head>
<body>
<form name="payment_form" method="GET" action="https://cp.define.pw/pay/">
' . $inputs . '
</form>
<script>document.payment_form.submit();</script>
</body>
</html>';

?>