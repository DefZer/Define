<?php
namespace modules\zerpay\controllers\front;

use front\ModuleFrontController;
use model\Bill;
use model\Client;
use model\Currency;
use modules\zerpay\classes\payment\ZerPayAPI;
use System\Config;
use System\Notifier;

class ZerpayStatusController extends ModuleFrontController{
    protected $auth = false;
    public function actionStatus(){
        $pconfig = new Config('payments');
        $zerpa =  new ZerPayAPI(array(
            'shop_id'       => $pconfig->zerpay->shop_id,
            'public_key'    => $pconfig->zerpay->public_key,
            'secret_key'   => $pconfig->zerpay->secret_key
        ));


        $payment = $zerpa->getPayment();
        if ($payment->verified) {
            $bill = new Bill($payment->getId());
            if ($bill->isLoadedObject() &&  $bill->total == $payment->getAmount()) {
                $bill->pay();
                $Client = new Client($bill->client_id);
                Notifier::PaidBill($Client, $bill);
                exit('OK');
            }
        }
        exit('ERROR');
    }
}