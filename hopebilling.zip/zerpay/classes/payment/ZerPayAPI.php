<?php

namespace modules\zerpay\classes\payment;

use payment\PaymentAPI;
use System\Exception;
use System\Logger;

class ZerPayAPI extends PaymentAPI
{
    public function setFormAction(){
        $this->_form_action = 'https://lk.zerpay.ru/pay/';
    }

    public function getFormValues()
    {
        $fields            = $this->getFields();
        $fields['sign']    = $this->getSign($fields);
        return $fields;
    }

    public function getFields()
    {
        $fields = [
            'shop_id'         => $this->_shop['shop_id'],
            'amount'        => $this->getAmountAsString(),
            'pay_id'         => $this->getId()
        ];
        return $fields;
    }

    public function getSign($fields)
    {
        $sign = md5($fields['shop_id'].':'.$this->getAmountAsString().':'.$this->_shop['public_key'].':'.$fields['pay_id']);
        return $sign;
    }
	
	final protected function _checkSignature(array $source)
    {
        Logger::log('ZerPay signature argument: '.$this->_shop['shop_id'].':'.$source['sum'].':'.$this->_shop['secret_key'].':'.$source['invoice']);
        Logger::log(json_encode($source));
        $sign = md5($this->_shop['shop_id'].':'.$source['sum'].':'.html_entity_decode($this->_shop['secret_key']).':'.$source['invoice']);
        if ((string)$sign === (string)$source['http_auth_signature']) {
            return true;
        }
        return false;
    }

    final protected function _checkIp(){
        if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) return $_SERVER['HTTP_CF_CONNECTING_IP'];
		if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
		if (isset($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
		return $_SERVER['REMOTE_ADDR'];
    }

    public function getPayment()
    {
        $source = $_REQUEST;
        if (!$source || empty($source)) {
            throw new Exception('Source not exist');
        }

		if (in_array(!$this->_checkIp(), ["185.217.199.13"])) {
			die("hacking attempt!");
		}

        if ($this->_checkSignature($source)) {
            $this->verified = true;
        } else {
            throw new Exception('error signature');
        }

        $this->_id          = $source['invoice'];
        $this->_amount      = $source['sum'];
        return $this;
    }
}