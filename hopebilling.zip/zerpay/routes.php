<?php
return array(
    'status' => 'front|ZerpayStatus|status',
    'result' => 'front|Zerpay|result'
);