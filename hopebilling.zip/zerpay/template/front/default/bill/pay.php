
<? if (isset($zerpay)) { ?>
    <form action="<?= $zerpay->getFormAction(); ?>" method="get">
        <?php foreach ($zerpay->getFormValues() as $field => $value): ?>
            <input type="hidden" name="<?= $field; ?>" value="<?= $value; ?>"/>
        <?php endforeach; ?>
        <button type="submit" class="payment_button"
                style="background: url(<?= $_->link('app/modules/zerpay/template/front/default/img/zerpay.png') ?>) no-repeat center;"></button>
    </form>
<? } ?>