<form method="post">
    <fieldset>
        <div class="form-group">
            <label><?=$_->l('ID магазина')?></label>
            <input type="text" id="disabledTextInput" name="shop_id"
                   value="<?= isset($pconfig->zerpay->shop_id) ? $pconfig->zerpay->shop_id : '' ?>"
                   class="form-control" placeholder="<?=$_->l('ID магазина')?>">
        </div>
        <div class="form-group">
            <label><?=$_->l('Публичный ключ')?></label>
            <input type="text" id="disabledTextInput" name="public_key"
                   value="<?= isset($pconfig->zerpay->public_key) ? $pconfig->zerpay->public_key : '' ?>"
                   class="form-control"
                   placeholder="<?=$_->l('Публичный ключ')?>">
        </div>
        <div class="form-group">
            <label><?=$_->l('Секретный ключ')?></label>
            <input type="text" id="disabledTextInput" name="secret_key"
                   value="<?= isset($pconfig->zerpay->secret_key) ? $pconfig->zerpay->secret_key : '' ?>"
                   class="form-control"
                   placeholder="<?=$_->l('Секретный ключ')?>">
        </div>
        <button type="submit" class="btn btn-primary"><?= $_->l('Сохранить') ?></button>
    </fieldset>
</form>