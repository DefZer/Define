<?php

namespace modules\zerpay;

use modules\zerpay\classes\payment\ZerPayAPI;
use model\Bill;
use model\Currency;
use stdClass;
use System\Config;
use System\Module;
use System\Router;
use System\Tools;

class zerpay extends Module{
    public $name = 'Платежная система zerpay.ru';
    public $author = '<a target="_blank" href="https://Gm24web.ru">Gm24Web.ru</a>';
    public $category = 3; // for payments systems

    public function install()
    {
        $pconfig                                 = new Config('payments');
        $pconfig->zerpay                      = new stdClass();
        $pconfig->zerpay->enable              = 0;
        $pconfig->zerpay->shop_id             = "";
        $pconfig->zerpay->public_key          = "";
        $pconfig->zerpay->secret_key         = "";
        $pconfig->save();
        $this->registerHook('displayPaymentMethods');
    }

    public function uninstall()
    {
        $pconfig = new Config('payments');
        $pconfig->delete('zerpay');
        $pconfig->save();
        return parent::uninstall();
    }

    public function displayPaymentMethods(&$view)
    {
        $pconfig = new Config('payments');
        $id_bill = Router::getParam(0);
        $Bill = new Bill($id_bill);
        $view = $this->getModuleView('bill/pay.php');
        $dcurrency = new Currency($this->config->currency_default);
        //zerpay
            $zerpay = new ZerPayAPI(array(
                'shop_id'       => $pconfig->zerpay->shop_id,
                'public_key'    => $pconfig->zerpay->public_key
            ));

            $payment          = $zerpay->createPayment(array(
                'id'          => $Bill->id,
                'amount'      => $Bill->total,
                'description' => 'Оплата услуг компании',
                'currency'    => $dcurrency->iso
            ));

            $view->zerpay = $payment;
        //zerpay end

        $view->id_bill = $id_bill;
    }

    public function actionSetting(){
        $pconfig = new Config('payments');
        if (Tools::rPOST()) {
            $pconfig->zerpay->shop_id       = Tools::rPOST('shop_id');
            $pconfig->zerpay->public_key         = Tools::rPOST('public_key');
            $pconfig->zerpay->secret_key         = Tools::rPOST('secret_key');
            $pconfig->save();
        }

        $view  = $this->getModuleView('setting.php', 'admin');
        $view->pconfig= $pconfig;
        $view->currencies = Currency::factory()->getRows();
        return $view;
    }
}