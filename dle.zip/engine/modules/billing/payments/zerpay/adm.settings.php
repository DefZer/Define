<?php if (!defined('BILLING_MODULE')) die("Hacking attempt!");

/**
 * ZerPay
 *
 * @link          https://zerpay.ru/
 */
class zerpay
{
    var $doc = 'https://lk.zerpay.ru/docs/module';

    function Settings($config)
    {
        $html = [];

        $html[] = [
            'ID Магазина:',
            'Из настроек магазина в личном кабинете zerpay.ru',
            '<input name="save_con[shop_id]" class="edit bk" type="text" value="' . $config['shop_id'] . '" style="width: 100%">',
        ];

        $html[] = [
            'Публичный ключ:',
			'Из настроек магазина в личном кабинете zerpay.ru',
            '<input name="save_con[public_key]" class="edit bk" type="password" value="' . $config['public_key'] . '" style="width: 100%">',
        ];

        $html[] = [
            'Секретный ключ:',
            'Из настроек магазина в личном кабинете zerpay.ru',
            '<input name="save_con[secret_key]" class="edit bk" type="password" value="' . $config['secret_key'] . '" style="width: 100%">',
        ];

        $html[] = [
            'IP фильтр:',
            'Список доверенных IP-адресов, наши адреса: 185.217.199.13',
            '<input name="save_con[ip_filter]" class="edit bk" type="text" value="' . $config['ip_filter'] . '" style="width: 100%">',
        ];


        return $html;
    }

    function Form($order_id, $config, $invoice, $description, $DevTools)
    {
        $amount = number_format($invoice['invoice_pay'], 2, '.', '') * 1;

        if (empty($description)) {
            $description = 'Balance ' . $invoice['invoice_user_name'];
        }
		
		$signature = md5($config['shop_id'].":$amount:".$config['public_key'].":$order_id");

        return '
            <form method="get" action="https://lk.zerpay.ru/pay/" accept-charset="UTF-8" id="paysys_form">
                <input type="hidden" name="shop_id" value="' . $config['shop_id'] . '" />
                <input type="hidden" name="amount" value="' . $amount . '" />
                <input type="hidden" name="pay_id" value="' . $order_id . '" />
                <input type="hidden" name="sign" value="' . $signature . '" />
                <input type="submit" class="btn" value="Оплатить">
            </form>';
    }

    function check_id($data)
    {
        return $data["invoice"];
    }

    function check_ok($data)
    {
        return 'OK';
    }

    function check_out($data, $config, $invoice)
    {
        global $_REQUEST;

        $valid_ip = false;
        $sIP = str_replace(' ', '', $config['ip_filter']);
        $array_IP = explode(',', $sIP);
        if (isset($_SERVER["HTTP_X_REAL_IP"])) {
            $cur_ip = $_SERVER["HTTP_X_REAL_IP"];
        }elseif (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
            $cur_ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
        } else {
            $cur_ip = $_SERVER["REMOTE_ADDR"];
        }
        if (in_array($cur_ip, $array_IP)) {
            $valid_ip = true;
        }

        if (!$valid_ip) {
            return 'Error: ip_checked';
        }
		
		$signatureGen = md5($config['shop_id'].":".$_REQUEST['sum'].":".$config['secret_key'].":".$_REQUEST['invoice']);

        if ((string)$signatureGen === (string)$_REQUEST["http_auth_signature"]) {
            return 200;
        } else {
            return 'Error: signature:: ' . $_REQUEST["http_auth_signature"] . ' != ' . $signatureGen;
        }
    }
}

$Paysys = new zerpay;
